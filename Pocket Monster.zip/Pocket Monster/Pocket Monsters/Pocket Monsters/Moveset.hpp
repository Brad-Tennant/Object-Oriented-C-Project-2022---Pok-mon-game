//
//  Moveset.hpp
//  Pocket Monsters
//
//  Created by James Palmer on 2022-03-30.
//

#ifndef Moveset_hpp
#define Moveset_hpp

#include <stdio.h>
#include <string>
#include <iostream>
using namespace std;

class Moveset
{
protected:
    string move;
    string type;
    double damage;
public:
    Moveset();
    Moveset(string m, string t, double dam);
    string getMoven() { return move; };
    string getType() { return type; };
    double getDamage() { return damage; };
    void setMove(string m) { move = m; };
    void setType(string t) { type = t; };
    void setDamage(double d) { damage = d; };

    void movelist(int n);
};


#endif /* Moveset_hpp */
