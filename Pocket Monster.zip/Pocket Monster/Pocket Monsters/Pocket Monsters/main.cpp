//
//  main.cpp
//  Pocket Monsters
//
//  Created by James Palmer on 2022-03-30.
//

#include <iostream>
#include <iomanip>
#include <string>
#include <time.h>
#include "Monster.hpp"
#include "Moveset.hpp"
#include "Terrain.hpp"
#include "Battle.hpp"

using namespace std;



int main() {
    srand(time(NULL));
    string name;
    Moveset* fl[3], * r[3], * el[3], * fi[3], * wa[3], * gr[3];
    Monster e[6];
    //creating enemy monsters and their moves
    fl[0] = new Moveset("Slice", "Normal", 25);
    fl[1] = new Moveset("Spit", "Water", 25);
    fl[2] = new Moveset("Wing Attack", "Flying", 30);
    e[0].setName("Batman");
    e[0].setStatus();
    e[0].setType("Flying");
    e[0].setHealth(100);
    e[0].setPower(35);
    e[0].setDefence(15);
    e[0].setMove1(*fl[0]);
    e[0].setMove2(*fl[1]);
    e[0].setMove3(*fl[2]);
    r[0] = new Moveset("Punch", "Normal", 25);
    r[1] = new Moveset("Ember", "Fire", 25);
    r[2] = new Moveset("Rockslide", "Ground", 30);
    e[1].setName("Boulder");
    e[1].setStatus();
    e[1].setType("Ground");
    e[1].setHealth(100);
    e[1].setPower(15);
    e[1].setDefence(35);
    e[1].setMove1(*r[0]);
    e[1].setMove2(*r[1]);
    e[1].setMove3(*r[2]);
    el[0] = new Moveset("Bite", "Normal", 25);
    el[1] = new Moveset("Vine Whip", "Grass", 25);
    el[2] = new Moveset("Lightning", "Electric", 30);
    e[2].setName("Sparkmouse");
    e[2].setStatus();
    e[2].setType("Electric");
    e[2].setHealth(100);
    e[2].setPower(25);
    e[2].setDefence(25);
    e[2].setMove1(*el[0]);
    e[2].setMove2(*el[1]);
    e[2].setMove3(*el[2]);
    fi[0] = new Moveset("Flop", "Normal", 25);
    fi[1] = new Moveset("Discharge", "Electric", 25);
    fi[2] = new Moveset("Scortch", "Fire", 30);
    e[3].setName("Cooker");
    e[3].setStatus();
    e[3].setType("Fire");
    e[3].setHealth(100);
    e[3].setPower(30);
    e[3].setDefence(20);
    e[3].setMove1(*fi[0]);
    e[3].setMove2(*fi[1]);
    e[3].setMove3(*fi[2]);
    wa[0] = new Moveset("Kick", "Normal", 25);
    wa[1] = new Moveset("Air Bomb", "Flying", 25);
    wa[2] = new Moveset("Squirt", "Water", 30);
    e[4].setName("Trout");
    e[4].setStatus();
    e[4].setType("Water");
    e[4].setHealth(100);
    e[4].setPower(20);
    e[4].setDefence(30);
    e[4].setMove1(*wa[0]);
    e[4].setMove2(*wa[1]);
    e[4].setMove3(*wa[2]);
    gr[0] = new Moveset("Thump", "Normal", 25);
    gr[1] = new Moveset("Root Attack", "ground", 25);
    gr[2] = new Moveset("Timber", "Grass", 30);
    e[5].setName("Trunks");
    e[5].setStatus();
    e[5].setType("Grass");
    e[5].setHealth(100);
    e[5].setPower(20);
    e[5].setDefence(30);
    e[5].setMove1(*gr[0]);
    e[5].setMove2(*gr[1]);
    e[5].setMove3(*gr[2]);
    int option;
    //game starting menu
    cout << "Welcome to Pocket Monsters!\n\n\nChoose an option.\n\n1: Start game\n2: Quit game\n";
   
    for(int a = 5; a <6;){
        cin >> option;

        switch (option) {

            case 1: cout << "Game Started.\n" << endl;
                a=7;
                break;
            case 2:
                cout << "Game Ended.\n" << endl;
                return 0;
                break;
            default:
                cout << "You must choose an option." << endl;
                

        }

    }
    //players option to choose their monster/rival monster
    cout << "\nChoose your monster.\n----------------------------\n1: Charmelizard, Fire Starter\n2: Squirtoise, Water Starter\n3: Bulbvenasaur, Grass Starter" << endl;
    int choice = 0;
    Monster mon, mon2;
    Moveset *move[3], *move2[3];

    for(int a = 5; a <6;)
    {
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "You chose Charmelizard." << endl;
            move[0] = new Moveset("Tackle", "Normal", 25);
            move[1] = new Moveset("Wing Attack", "Flying", 25);
            move[2] = new Moveset("Flamethrower", "Fire", 30);
            mon.setName("Charmelizard");
            mon.setStatus();
            mon.setType("Fire");
            mon.setHealth(100);
            mon.setPower(30);
            mon.setDefence(20);
            mon.setMove1(*move[0]);
            mon.setMove2(*move[1]);
            mon.setMove3(*move[2]);

            move2[0] = new Moveset("Scratch", "Normal", 25);
            move2[1] = new Moveset("Rollout", "Ground", 25);
            move2[2] = new Moveset("Hydro Pump", "Water", 30);
            mon2.setName("Squirtoise");
            mon2.setStatus();
            mon2.setType("Water");
            mon2.setHealth(100);
            mon2.setPower(20);
            mon2.setDefence(30);
                mon2.setMove1(*move[0]);
                mon2.setMove2(*move[1]);
                mon2.setMove3(*move[2]);
            
                a=7;
            break;
        case 2:
            cout << "You Chose Squirtoise." << endl;
            move[0] = new Moveset("Scratch", "Normal", 25);
            move[1] = new Moveset("Rollout", "Ground", 25);
            move[2] = new Moveset("Hydro Pump", "Water", 30);
            mon.setName("Squirtoise");
            mon.setStatus();
            mon.setType("Water");
            mon.setHealth(100);
            mon.setPower(20);
            mon.setDefence(30);
                mon.setMove1(*move[0]);
                mon.setMove2(*move[1]);
                mon.setMove3(*move[2]);

            move2[0] = new Moveset("Bite", "Normal", 25);
            move2[1] = new Moveset("Stun", "Electric", 25);
            move2[2] = new Moveset("Leaf Blower", "Grass", 30);
            mon2.setName("Bulbvenasaur");
            mon2.setStatus();
            mon2.setType("Grass");
            mon2.setHealth(100);
            mon2.setPower(25);
            mon2.setDefence(25);
                mon2.setMove1(*move[0]);
                mon2.setMove2(*move[1]);
                mon2.setMove3(*move[2]);
                a=7;
            break;
        case 3:
            cout << "You Chose Bulbvenasaur." << endl;
            move[0] = new Moveset("Bite", "Normal", 25);
            move[1] = new Moveset("Stun", "Electric", 25);
            move[2] = new Moveset("Leaf Blower", "Grass", 30);
            mon.setName("Bulbvenasaur");
            mon.setStatus();
            mon.setType("Grass");
            mon.setHealth(100);
            mon.setPower(25);
            mon.setDefence(25);
                mon.setMove1(*move[0]);
                mon.setMove2(*move[1]);
                mon.setMove3(*move[2]);

            move2[0] = new Moveset("Tackle", "Normal", 25);
            move2[1] = new Moveset("Wing Attack", "Flying", 25);
            move2[2] = new Moveset("Flamethrower", "Fire", 30);
            mon2.setName("Charmelizard");
            mon2.setStatus();
            mon2.setType("Fire");
            mon2.setHealth(100);
            mon2.setPower(30);
            mon2.setDefence(20);
                mon2.setMove1(*move[0]);
                mon2.setMove2(*move[1]);
                mon2.setMove3(*move[2]);
                a=7;
            break;
        default:
            cout << "Choose a valid option: 1, 2, or 3." << endl;
        }
    }
   
    
    
    //players option to choose a new name
    cout << "\nWould you like to change the name of your monster? (Y/N)" << endl;
    for(int a = 5; a < 6;){
        char loption;
        cin >> loption;
        switch(loption){
            case 'Y':{
                string newname;
                cout << "\nEnter new name." << endl;
                cin >> newname;
                mon.setName(newname);
                cout << "\nYour monsters name is: " << mon.getName() << endl;
                a=7;
                break;
            }
            case 'N':
                a=7;
                break;
            default:
                cout << "You must choose an option (Y/N)" << endl;
    
        }
    }
    
    //creating different locations for each battle
    Terrain T1("Swamp", "Rain");
    T1.Effect();
    Terrain T2("Field", "Wind");
    T2.Effect();
    Terrain T3("Beach", "Storm");
    T3.Effect();
    Terrain T4("Desert", "Heat");
    T4.Effect();
    Terrain T5("Forest", "Tropical");
    T5.Effect();
    Terrain T6("Mountain", "Rocky");
    T6.Effect();

    Terrain allterrains[6] = { T1,T2,T3,T4,T5,T6 };

    Terrain location[4];

    int w = 0;
    int x = 0;
    int y = 0;
    int z = 0;
    do {
        w = rand() % 6;
        x = rand() % 6;
        y = rand() % 6;
        z = rand() % 6;
    } while (w == x && w == y && w == z && x == y && x == z && y == z);

    location[0] = allterrains[w];
    location[1] = allterrains[x];
    location[2] = allterrains[y];
    location[3] = allterrains[z];

    //Level 1
    cout << "Entering your first Pocket Monster Battle!\n" << endl;
    cout << "\nLocation: " << location[0].GetTerrain() << endl;
    cout << "Due to the surroundings " << allterrains[w].GetStrength() << " type monsters are strengthened and " << allterrains[w].GetWeak() << " type monsters are weakened!" << endl;

    int b;
    
    int c = rand() % 6;
    Battle b1(mon, e[c], location[0]);
    b = 5;
    cout << "\nYou have encountered " << b1.getM2().getName() << "! Now entering the battle. \n" << endl;
    while ((b1.getM1().getHealth() > 0 && b1.getM2().getHealth() > 0) || (b < 6)){
        int num;
        
        cout << b1.getM1().getName() << "'s health: " << b1.getM1().getHealth() << " / 100" << endl;
        cout << b1.getM2().getName() << "'s health: " << b1.getM2().getHealth() << " / 100" << endl;
        cout << "\nWhat will you do?\n\n1: Attack\n2: Flee\n3: Scan\n";
        for(int a = 5; a < 6;){
            cin >> num;
            switch (num) {
            case 1: int number;
                    cout << "Choose an attack.\n\n";
                    b1.getM1().movelist();
                cin >> number;
                b1.attack(mon.getMove(number));
                    a=7;
                break;
                
            case 2:
                if (b1.flee() == true){
                    b = 7;
                    e[c].setHealth(0);
                }
                a=7;
                break;
            case 3: b1.Scanner(b1.getM2());
                break;
            default: cout << "You must choose an option." << endl;

            }
        }
        if(b1.getM2().getHealth() > 0){

            int i = (rand() % 3)+1;
            b1.defend(b1.getM2().getMove(i));
        }
        if (b1.getM1().getHealth() <= 0){
            
            if (b1.getM1().getHealth() <= 0) {

                cout << "\nYour monster has died. The game has ended." << endl;
                return 0;
            }

        }
        if (b1.getM2().getHealth() <= 0 && b < 6) {
            cout << "\nYou defeated " << b1.getM2().getName() << "!" << endl;
            b1.~Battle();
            b = 7;
        }
    }

    
    b = 5;
    
    mon.setHealth(100);
    //Level 2
    cout << "Entering level 2!\n" << endl;
    cout << "\nLocation: " << location[1].GetTerrain() << endl;
    cout << "Due to the surroundings " << allterrains[x].GetStrength() << " type monsters are strengthened and " << allterrains[x].GetWeak() << " type monsters are weakened!" << endl;

   
    
    int d = rand() % 6;
    
    while(d == c ){
    d = rand() % 6;
    }
    Battle b2(mon, e[d], location[1]);
    b = 5;
    cout << "\nYou have encountered " << b2.getM2().getName() << "! Now entering the battle. \n" << endl;
    while ((b2.getM1().getHealth() > 0 && b2.getM2().getHealth() > 0) || (b < 6)){
        int num;
        
        cout << b2.getM1().getName() << "'s health: " << b2.getM1().getHealth() << " / 100" << endl;
        cout << b2.getM2().getName() << "'s health: " << b2.getM2().getHealth() << " / 100" << endl;
        cout << "\nWhat will you do?\n\n1: Attack\n2: Flee\n3: Scan\n";
        for(int a = 5; a < 6;){
            cin >> num;
            switch (num) {
            case 1: int number;
                    cout << "Choose an attack.\n\n";
                    b2.getM1().movelist();
                cin >> number;
                b2.attack(mon.getMove(number));
                    a=7;
                break;
                
            case 2:
                if (b2.flee() == true){
                    b = 7;
                    e[d].setHealth(0);
                }
                a=7;
                break;
            case 3: b2.Scanner(b2.getM2());
                break;
            default: cout << "You must choose an option." << endl;

            }
        }
        if(b2.getM2().getHealth() > 0){

            int i = (rand() % 3)+1;
            b2.defend(b2.getM2().getMove(i));
        }
        if (b2.getM1().getHealth() <= 0){
            
            if (b2.getM1().getHealth() <= 0) {

                cout << "\nYour monster has died. The game has ended." << endl;
                return 0;
            }

        }
        if (b2.getM2().getHealth() <= 0 && b < 6) {
            cout << "\nYou defeated " << b2.getM2().getName() << "!" << endl;
            b2.~Battle();
            b = 7;
        }
    }
    

    b = 5;
    
    mon.setHealth(100);
    //Level 3
    cout << "Entering level 3!\n" << endl;
    cout << "\nLocation: " << location[2].GetTerrain() << endl;
    cout << "Due to the surroundings " << allterrains[y].GetStrength() << " type monsters are strengthened and " << allterrains[y].GetWeak() << " type monsters are weakened!" << endl;

 
    
    int f = rand() % 6;
    while(f == c || f == d){
    f = rand() % 6;
    }
    Battle b3(mon, e[f], location[2]);
    b = 5;
    cout << "\nYou have encountered " << b3.getM2().getName() << "! Now entering the battle. \n" << endl;
    while ((b3.getM1().getHealth() > 0 && b3.getM2().getHealth() > 0) || (b < 6)){
        int num;
        
        cout << b3.getM1().getName() << "'s health: " << b3.getM1().getHealth() << " / 100" << endl;
        cout << b3.getM2().getName() << "'s health: " << b3.getM2().getHealth() << " / 100" << endl;
        cout << "\nWhat will you do?\n\n1: Attack\n2: Flee\n3: Scan\n";
        for(int a = 5; a < 6;){
            cin >> num;
            switch (num) {
            case 1: int number;
                    cout << "Choose an attack.\n\n";
                    b3.getM1().movelist();
                cin >> number;
                b3.attack(mon.getMove(number));
                    a=7;
                break;
                
            case 2:
                if (b3.flee() == true){
                    b = 7;
                    e[f].setHealth(0);
                }
                a=7;
                break;
            case 3: b3.Scanner(b3.getM2());
                break;
            default: cout << "You must choose an option." << endl;

            }
        }
        if(b3.getM2().getHealth() > 0){

            int i = (rand() % 3)+1;
            b3.defend(b3.getM2().getMove(i));
        }
        if (b3.getM1().getHealth() <= 0){
            
            if (b3.getM1().getHealth() <= 0) {

                cout << "\nYour monster has died. The game has ended." << endl;
                return 0;
            }

            
        }
        if (b3.getM2().getHealth() <= 0 && b < 6) {
            cout << "\nYou defeated " << b3.getM2().getName() << "!" << endl;
            b3.~Battle();
            b = 7;
        }
    }

        b = 5;
        
        mon.setHealth(100);
    //Level 4
    cout << "Entering the last battle against your rival monster!\n" << endl;
    cout << "Location: " << location[3].GetTerrain() << endl;
    cout << "Due to the surroundings " << allterrains[z].GetStrength() << " type monsters are strengthened and " << allterrains[z].GetWeak() << " type monsters are weakened!" << endl;
    
    int g = rand() % 6;
    while(g == c || g == d || g == f){
        g = rand() % 6;
    }
    Battle b4(mon, mon2, location[3]);
    b = 5;
    cout << "You have encountered " << b4.getM2().getName() << "! Now entering the battle. \n" << endl;
    while ((b4.getM1().getHealth() > 0 && b4.getM2().getHealth() > 0) || (b < 6)){
        int num;
        
        cout << b4.getM1().getName() << "'s health: " << b4.getM1().getHealth() << " / 100" << endl;
        cout << b4.getM2().getName() << "'s health: " << b4.getM2().getHealth() << " / 100" << endl;
        cout << "\nWhat will you do?\n\n1: Attack\n2: Flee\n3: Scan\n";
        for(int a = 5; a < 6;){
            cin >> num;
            switch (num) {
            case 1: int number;
                    cout << "\nChoose an attack.\n\n";
                    b4.getM1().movelist();
                cin >> number;
                b4.attack(mon.getMove(number));
                    a=7;
                break;
                
            case 2:
                if (b4.flee() == true){
                    b = 7;
                    mon2.setHealth(0);
                }
                a=7;
                break;
            case 3: b4.Scanner(b4.getM2());
                break;
            default: cout << "You must choose an option." << endl;

            }
        }
        if(b4.getM2().getHealth() > 0){

            int i = (rand() % 3)+1;
            b4.defend(b4.getM2().getMove(i));
        }
        if (b4.getM1().getHealth() <= 0){
            
            if (b4.getM1().getHealth() <= 0) {

                cout << "\nYour monster has died. The game has ended." << endl;
                return 0;
            }

            }
        if (b4.getM2().getHealth() <= 0 && b < 6) {
            cout << "\nYou defeated " << b4.getM2().getName() << "!" << endl;
            b4.~Battle();
            b = 7;
        }
    }

        b = 5;
        
        mon.setHealth(100);

    //endgame
    cout << "\nYou beat Pocket Monsters, thank you for playing!" << endl;
    return(0);

}

