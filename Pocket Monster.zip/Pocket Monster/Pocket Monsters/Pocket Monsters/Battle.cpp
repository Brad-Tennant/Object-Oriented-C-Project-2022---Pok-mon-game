//
//  Battle.cpp
//  Pocket Monsters
//
//  Created by James Palmer on 2022-03-30.
//

#include "Battle.hpp"


Battle::Battle(Monster mon1, Monster mon2, Terrain wea): Terrain(wea) {
    m1 = mon1;
    m2 = mon2;
    weather = wea;
    if (weather.GetStrength() == m1.getMType())
        m1.setPower(m1.getPower() * 1.15);
    if (weather.GetStrength() == m2.getMType())
        m2.setPower(m2.getPower() * 1.15);
    if (weather.GetWeak() == m1.getMType())
        m1.setPower(m1.getPower() * 0.85);
    if (weather.GetWeak() == m2.getMType())
        m2.setPower(m2.getPower() * 0.85);

}

Battle::~Battle(){
    if(weather.GetStrength() == m1.getMType())
       m1.setPower(m1.getPower() / 1.15);
    if(weather.GetWeak() == m1.getMType())
       m1.setPower(m1.getPower() / 0.85);
}
    
double Battle::effect(Moveset move){
   if(move.getType() == "Fire" && m2.getMType() == "Grass")
      return 2;
   if(move.getType() == "Grass" && m2.getMType() == "Water")
      return 2;
   if(move.getType() == "Water" &&m2.getMType() == "Fire")
      return 2;
   if(move.getType() == "Grass" && m2.getMType() == "Fire")
      return 0.5;
   if(move.getType() == "Water" && m2.getMType() == "Grass")
      return 0.5;
   if(move.getType() == "Fire" &&m2.getMType() == "Water")
      return 0.5;
   if(move.getType() == "Electric" && m2.getMType() == "Flying")
       return 2;
   if(move.getType() == "Flying" && m2.getMType() == "Ground")
       return 2;
   if(move.getType() == "Ground" && m2.getMType() == "Electric")
       return 2;
   if(move.getType() == "Flying" && m2.getMType() == "Electric")
       return 0.5;
   if(move.getType() == "Ground" && m2.getMType() == "Flying")
       return 0.5;
   if(move.getType() == "Electric" && m2.getMType() == "Ground")
       return 0.5;
   else
       return 1;
    }

    double Battle::eeffect(Moveset move){
   if(move.getType() == "Fire" && m1.getMType() == "Grass")
      return 2;
   if(move.getType() == "Grass" && m1.getMType() == "Water")
      return 2;
   if(move.getType() == "Water" &&m1.getMType() == "Fire")
      return 2;
   if(move.getType() == "Grass" && m1.getMType() == "Fire")
      return 0.5;
   if(move.getType() == "Water" && m1.getMType() == "Grass")
      return 0.5;
   if(move.getType() == "Fire" && m1.getMType() == "Water")
      return 0.5;
   if(move.getType() == "Electric" && m1.getMType() == "Flying")
       return 2;
   if(move.getType() == "Flying" && m1.getMType() == "Ground")
       return 2;
   if(move.getType() == "Ground" && m1.getMType() == "Electric")
       return 2;
   if(move.getType() == "Flying" && m1.getMType() == "Electric")
       return 0.5;
   if(move.getType() == "Ground" && m1.getMType() == "Flying")
       return 0.5;
   if(move.getType() == "Electric" && m1.getMType() == "Ground")
       return 0.5;
   else
       return 1;
    }


void Battle::attack(Moveset move) {

    cout << m1.getName() << " used " << move.getMoven() << "." << endl;
        double attack = (m1.getPower() * (move.getDamage() / m2.getDefence())) * effect(move);
    m2.setHealth(m2.getHealth() - attack);
    
    if(effect(move) == 2)
        cout << "Super effective!" << endl;
    if(effect(move) == 0.5)
        cout << "Not very effective..." << endl;
    cout << m1.getName() << " dealt " << attack << " damage." << endl;

}

void Battle::defend(Moveset move) {

    cout << m2.getName() << " used " << move.getMoven() << "." << endl;
        double attack = (m2.getPower() * (move.getDamage() / m1.getDefence())) * eeffect(move);
    m1.setHealth(m1.getHealth() - attack);
    
    if(eeffect(move) == 2)
        cout << m2.getName() << "'s attack was super effective!" << endl;
    if(eeffect(move) == 0.5)
        cout << m2.getName() << "'s attack was not very effective..." << endl;
    cout << m2.getName() << " dealt " << attack << " damage." << endl;
}

bool Battle::flee(){

    int i = rand() % 10;
    if (i == 0) {
        cout << "Attempt to flee successful! " << endl;
        m2.setHealth(0);
        return true;
   }
    else
        cout << "Attempt to flee failed!" << endl;
      return false;
}



void Battle::Scanner(Monster mon) {

    cout << "Enemy Monster type : " << mon.getMType() << endl;
    cout << "Enemy Monster health : " << mon.getHealth() << endl;
    cout << "Enemy Monster power : " << mon.getPower() << endl;
    cout << "Enemy Monster defence : " << mon.getDefence() << endl;
}

void Battle::print() {

    cout << m1.getName() << "'s status: " << m1.getStatus() << endl;
    cout << m1.getName() << "'s health: " << m1.getHealth() << endl;
}
