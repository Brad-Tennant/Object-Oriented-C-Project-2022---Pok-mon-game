//
//  Moveset.cpp
//  Pocket Monsters
//
//  Created by James Palmer on 2022-03-30.
//

#include "Moveset.hpp"


Moveset::Moveset(){
    move = "";
    type = "";
    damage = 0;
}
Moveset::Moveset(string m, string t, double dam){
    move = m;
    type = t;
    damage = dam;
}

void Moveset::movelist(int n){
    cout << n+1 << ": " << move << ", " << type << " type." <<  endl;
}
