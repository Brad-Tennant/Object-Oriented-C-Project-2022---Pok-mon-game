//
//  Terrain.cpp
//  Pocket Monsters
//
//  Created by James Palmer on 2022-03-30.
//

#include "Terrain.hpp"

Terrain::Terrain() {

    terrain = " ";
    weather = " ";
    strengthenType = " ";
    weakenType = " ";
}

Terrain::Terrain(string t, string wea){

    terrain = t;
    weather = wea;
}

void Terrain::Effect(){

    if (terrain == "Swamp") {
    
        weather = "Rain";
        strengthenType = "Water";
        weakenType = "Fire";
    }

    if (terrain == "Field") {
    
        weather = "Wind";
        strengthenType = "Air";
        weakenType = "Ground";
    }

    if (terrain == "Beach") {
    
        weather = "Storm";
        strengthenType = "Electric";
        weakenType = "Air";
    }

    if (terrain == "Desert") {

        weather = "Heat";
        strengthenType = "Fire";
        weakenType = "Grass";
    }

    if (terrain == "Forest") {
    
        weather = "Tropical";
        strengthenType = "Grass";
        weakenType = "Water";
    }

    if (terrain == "Mountain") {
        
        weather = "Rocky";
        strengthenType = "Ground";
        weakenType = "Electric";
    }
}
