//
//  Terrain.hpp
//  Pocket Monsters
//
//  Created by James Palmer on 2022-03-30.
//

#ifndef Terrain_hpp
#define Terrain_hpp

#include <stdio.h>
#include <string>
using namespace std;

class Terrain
{
    string terrain;
    string weather;
    string strengthenType;
    string weakenType;

public:

    Terrain();
    Terrain(string t, string wea);
    
    string GetTerrain() { return terrain; };
    string GetWeather() { return weather; };
    string GetStrength() { return strengthenType; };
    string GetWeak() { return weakenType; };
    void setTerrain(string t) { terrain = t; };
    void SetWeather(string wea) { wea = weather; };
    void SetStrength(string s) { s = strengthenType; };
    void SetWeak(string w) { w = weakenType; };

    void Effect();
};


#endif /* Terrain_hpp */
