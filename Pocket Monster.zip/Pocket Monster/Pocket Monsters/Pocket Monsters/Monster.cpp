//
//  Monster.cpp
//  Pocket Monsters
//
//  Created by James Palmer on 2022-03-30.
//

#include "Monster.hpp"



Monster::Monster(){
    name = "";
    status = "alive";
    mtype = "";
    health = 0;
    power = 0;
    defence = 0;

    
}
Monster::Monster(string n, string s, string mt, double h, double p, double d, Moveset move[]){
        
    name = n;
    status = s;
    mtype = mt;
    health = h;
    power = p;
    defence = d;
    move1 = move[0];
    move2 = move[1];
    move3 = move[2];
}

string Monster::getMovename(int m) {
    if(m == 1)
        return move1.getMoven();
    if(m == 2)
        return move2.getMoven();
    if(m == 3)
        return move3.getMoven();
    else
        return 0;
}

Moveset Monster::getMove(int n){
    if(n == 1)
        return move1;
    if(n == 2)
        return move2;
    if(n == 3)
        return move3;
    else
        return Moveset();
}

void Monster::setStatus() {
    if (health > 0)
        status = "alive";
    
    if (health <= 0)
        status = "dead";

}

void Monster::setMove1(Moveset move) {

    move1 = move;
    
}

void Monster::setMove2(Moveset move) {

    move2 = move;
    
}

void Monster::setMove3(Moveset move) {

    move3 = move;
    
}
void Monster::print(){
        cout << "Monster name : " << name << endl;
        cout << "Health : " << health << endl;
        cout << "Type: " << mtype << endl;
        cout << "Power : " << power << endl;
        cout << "Defense : " << defence << endl;
}

void Monster::movelist(){
    move1.movelist(0);
    move2.movelist(1);
    move3.movelist(2);
}
