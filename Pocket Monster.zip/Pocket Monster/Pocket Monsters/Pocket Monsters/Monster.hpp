//
//  Monster.hpp
//  Pocket Monsters
//
//  Created by James Palmer on 2022-03-30.
//

#ifndef Monster_hpp
#define Monster_hpp

#include <stdio.h>
#pragma once
#include <string>
#include "Moveset.hpp"
#include <iostream>
using namespace std;

class Monster
{
public:
    string name;
    string status;
    string mtype;
    double health;
    double power;
    double defence;
    Moveset move1;
    Moveset move2;
    Moveset move3;


public:
    Monster();
    Monster(string n, string s, string mt, double h, double p, double d, Moveset move[]);
    string getName() { return name; };
    string getStatus() { return status; };
    string getMType() { return mtype; };
    double getHealth() { return health; };
    double getPower() { return power; };
    double getDefence() { return defence; };
    Moveset getMove(int n);
    string getMovename(int m);
    void setName(string n) { name = n; };
    void setStatus();
    void setType(string mt) { mtype = mt; };
    void setHealth(double h) { health = h; }
    void setPower(double p) { power = p; };
    void setDefence(double d) { defence = d; };
    void setMove1(Moveset move);
    void setMove2(Moveset move);
    void setMove3(Moveset move);
    
    void print();
    void movelist();
   
};

#endif /* Monster_hpp */
