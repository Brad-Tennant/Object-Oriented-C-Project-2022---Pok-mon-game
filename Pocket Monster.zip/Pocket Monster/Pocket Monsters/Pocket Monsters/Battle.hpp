//
//  Battle.hpp
//  Pocket Monsters
//
//  Created by James Palmer on 2022-03-30.
//

#ifndef Battle_hpp
#define Battle_hpp

#include <stdio.h>
#include <cmath>
#include <iostream>
#include "Monster.hpp"
#include "Moveset.hpp"
#include "Terrain.hpp"
using namespace std;

class Battle : public Monster, Terrain
{
    protected:
        Monster m1;
        Monster m2;
        Terrain weather;
    public:
        Battle(Monster mon1, Monster mon2, Terrain wea);
        ~Battle();
        Monster getM1() { return m1; };
        Monster getM2() { return m2; };
        Terrain getWeather() { return weather; };
        void setM1(Monster mon1) { mon1 = m1; };
        void setM2(Monster mon2) { mon2 = m2;  };
        void setWeather(Terrain wea) { wea = weather; };
        double effect(Moveset move);
        double eeffect(Moveset move);
        void attack(Moveset move);
        void defend(Moveset move);
        bool flee();
        void Scanner(Monster mon);
        void print();
    
};


#endif /* Battle_hpp */
